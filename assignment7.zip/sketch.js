let timer = 1000;
let nextChange = timer;

function setup() {
  createCanvas(800, 400);
  colorMode(RGB, 255, 255, 255, 1);
  ellipseMode(RADIUS);
  angleMode(DEGREES);
}

function draw() {
  background(137, 207, 240);

  sun();
  water();
}

function sun() {
  push();

  //translate(60,60)
  translate(400, 420);
  translate(p5.Vector.fromAngle(millis() / 2000, 370));
  noStroke();
  fill(255, 220, 80, 0.5);
  ellipse(0, 0, 80, 80);
  fill(255, 220, 80);
  ellipse(0, 0, 60, 60);

  fill(15);
  beginShape();
  line(5, -20, 115, -20);
  bezier(-55, -20, -50, 20, -5, 20, 0, -20);
  bezier(0, -20, 5, 20, 50, 20, 55, -20);
  endShape();
  stroke(233, 116, 81);
  strokeWeight(3);
  noFill();
  bezier(-20, 30, -5, 40, 10, 40, 20, 30);
  stroke(255);
  beginShape();
  line(-42, 0, -30, -17);
  line(17, 0, 27, -17);
  endShape();
  pop();
}
function water() {
  scale(2);
  water1 = [color("#00308F"), "#51A8BEFl4", "#5072A7"];
  water2 = random(water1);

  noStroke();
  translate(0, 10);

  for (let i = 0; i < 900; i++) {
    let r = random(0, 90);
    if (millis() > nextChange) {
      fill(water2);

      nextChange = millis() + timer;
    }
    ellipse(i, r / 2, 2, 2);
    rotate(sin(2));
  }
  return water;
}
