var fillValue = 255;
var circleX, circleY, circleRad;
var x = 320, y = 310, w = 60, h = 20;
let bu1, bu2
var start, current

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  initCircle();
  frameRate(2)
}

function draw() {
  background(204);
  noStroke()
  fill(200,230,255)
  rect(0,0,400,260)
  fill(60,35,25)
  rect(0,260,400,400)
  fill(40)
  stroke(80,80,82)
  strokeWeight(6)
  quad(22,302,378,302,460,410,-60,410) // keyboard plate
 
  push()
  //screen
  stroke(0)
  noStroke()
  fill(120,120,140);
  rect(25,25,355,275)
  stroke(0)
  noFill()
  strokeWeight(20);
  rect(30,25,340,265)  
  pop()
 
  //power button
  let col = color(195, 177, 225);
  bu1 = createButton("power (p)");
  bu1.style('font-size','10px')
  bu1.position(x, y);
  bu1.size(w, h);
  bu1.style("background-color", col);
  bu1.keyPressed;
  push()
  //bounds of circle
  if(mouseX > (circleX - circleRad/2) 
      && mouseX < (circleX + circleRad/2) 
  		&& mouseY > (circleY - circleRad/2) 
          && mouseY < (circleY + circleRad/2)
             && (mouseIsPressed == true)
  	
  		) {
   fillValue = color(253, 253, 150); 
  } else {
   fillValue = 255; }
   fill(fillValue);
   stroke(0);
   strokeWeight(2);
   ellipse(70,65,30);
  pop()
}
  
//circle
function initCircle() {
  circleX = 70;
  circleY = 65;
  circleRad = 30;
}

function keyPressed() {
  //power button, press P in bounds
  if (
    mouseX > x && mouseX < x + w &&
    mouseY > y && mouseY < y + h &&
    key == "p") {
    fill(0,10,25)
    noStroke()
    rect(40,35,320,245)
    noLoop()
}
  else {
    text('...',200,200)
  }
}