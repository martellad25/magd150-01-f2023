var scribble1 = new Scribble(); 
var scribble2 = new Scribble();
var scribble3 = new Scribble();
var scribble4 = new Scribble();
var scribble5 = new Scribble();
var scribbleF = new Scribble();
var scribble = new Scribble();
let angle = 0;

function setup() {
  createCanvas(600, 600);
  frameRate(3);
  angleMode(DEGREES);
}

function draw() {
  background(color("rgb(254,142,162)"));
  stroke(color("rgb(255,255,137)"));
  strokeWeight(4);
  translate(0, 100);
  let xCoords = [228, 150, 250, 300, 350, 455, 372, 400, 300, 210];
  let yCoords = [297, 220, 200, 110, 200, 220, 297, 400, 350, 400];
  angle = random(0, 360);
  scribbleF.scribbleFilling(xCoords, yCoords, 8, angle);

  stroke(color("rgb(97,97,242)"));
  beginShape();

  scribble1.scribbleCurve(250, 200, 350, 200, 310, 75, 290, 75); //top point
  scribble2.scribbleCurve(350, 200, 372, 297, 490, 210, 490, 210); //right point
  scribble3.scribbleCurve(372, 297, 300, 350, 430, 430, 410, 420); //bottom right
  scribble4.scribbleCurve(228, 297, 300, 350, 190, 420, 200, 430); //bottom left
  scribble5.scribbleCurve(250, 200, 228, 297, 120, 210, 120, 210); //left point
  endShape();
  translate(0, -100);
  textDraw();
}

function textDraw() {
  let scrS = new Scribble();
  let scrSa = new Scribble();
  let scrS2 = new Scribble();
  let scrC = new Scribble();
  let scrR = new Scribble();
  let scrRa = new Scribble();
  let scrI = new Scribble();
  let scrB1 = new Scribble();
  let scrB2 = new Scribble();
  let scrB1a = new Scribble();
  let scrB2a = new Scribble();
  let scrL = new Scribble();
  let scrE = new Scribble();
  let scrE1 = new Scribble();

  stroke(color("purple"));

  translate(0, 20);
  scrS2.scribbleCurve(105, 50, 75, 100, 30, 60, 150, 80);
  scrC.scribbleCurve(165, 100, 165, 75, 120, 105, 140, 35);
  scrR.scribbleLine(195, 60, 195, 100);
  scrRa.scribbleCurve(195, 70, 225, 70, 210, 60, 210, 60);
  scrI.scribbleLine(270, 60, 270, 100);
  scrB1.scribbleLine(315, 30, 315, 100);
  scrB2.scribbleCurve(315, 60, 315, 100, 350, 70, 350, 105);
  scrB1a.scribbleLine(375, 30, 375, 100);
  scrB2a.scribbleCurve(375, 60, 375, 100, 410, 70, 410, 105);
  scrL.scribbleCurve(440, 30, 460, 90, 430, 120, 450, 100);
  scrE.scribbleLine(495, 75, 525, 75);
  scrE1.scribbleCurve(525, 100, 525, 75, 480, 105, 500, 35);

  let heart = new Scribble();
  let heart1 = new Scribble();

  push();
  strokeWeight(2);
  heart.scribbleCurve(270, 44, 270, 52, 260, 40, 260, 44);
  heart1.scribbleCurve(270, 44, 270, 52, 280, 40, 280, 44);
  pop();

  translate(0, -20);
}
